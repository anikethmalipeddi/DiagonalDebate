import Link from "next/link"
import { Scale } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-white-800 text-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-red-600 p-2 rounded-lg">
                <Scale className="h-6 w-6 text-g" />
              </div>
              <span className="text-xl font-bold">DiagonalDebate</span>
            </div>
            <p className="text-black-300 mb-4">
              Empowering high school congressional debate students with AI-powered legislation tools and educational
              resources.
            </p>
            <p className="text-sm text-black-400">Version 1.0.0</p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-black-100">Platform</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/legislation-checker" className="text-black-300 hover:text-white transition-colors">
                  Legislation Checker
                </Link>
              </li>
              <li>
                <Link href="/lessons" className="text-black-300 hover:text-white transition-colors">
                  Lessons
                </Link>
              </li>
              <li>
                <Link href="/contention-ideas" className="text-black-300 hover:text-white transition-colors">
                  Contention Ideas
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-black-100">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-black-300 hover:text-white transition-colors">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-black-300 hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/help" className="text-black-300 hover:text-white transition-colors">
                  Help Center
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-black-300">© 2024 DiagonalDebate. Built for Rock Ridge High School Debate Team.</p>
        </div>
      </div>
    </footer>
  )
}
