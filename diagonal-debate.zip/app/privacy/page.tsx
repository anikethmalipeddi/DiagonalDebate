import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Lock, Eye, Database, UserCheck } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">Legal</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Privacy <span className="text-red-600">Policy</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Your privacy and data security are our highest priorities
            </p>
            <p className="text-sm text-gray-500">Last updated: June 20, 2025</p>
          </div>
        </div>
      </section>

      {/* Privacy Content */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {/* Security Emphasis */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Shield className="h-8 w-8 text-red-600" />
                  <CardTitle className="text-2xl text-red-800">Security-First Approach</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-red-700 mb-4">
                  DiagonalDebate is built with security as our foundation. We implement multiple layers of protection
                  including end-to-end encryption, secure data transmission, regular security audits, and strict access
                  controls to ensure your information remains private and secure.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-2">
                    <Lock className="h-4 w-4 text-red-600" />
                    <span className="text-sm text-red-700">256-bit Encryption</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Database className="h-4 w-4 text-red-600" />
                    <span className="text-sm text-red-700">Secure Storage</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <UserCheck className="h-4 w-4 text-red-600" />
                    <span className="text-sm text-red-700">Access Controls</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Privacy Sections */}
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">1. Information We Collect</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Personal Information</h4>
                  <p className="text-gray-700 mb-2">When you create an account, we collect:</p>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 ml-4">
                    <li>Name and email address</li>
                    <li>School affiliation (Rock Ridge High School)</li>
                    <li>Account credentials (securely hashed passwords)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Content Information</h4>
                  <p className="text-gray-700 mb-2">When you use our services, we collect:</p>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 ml-4">
                    <li>Legislation text and documents you create</li>
                    <li>Usage data and interaction patterns</li>
                    <li>Feedback and improvement suggestions</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Technical Information</h4>
                  <p className="text-gray-700 mb-2">We automatically collect:</p>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 ml-4">
                    <li>IP address and browser information</li>
                    <li>Device and operating system details</li>
                    <li>Usage analytics and performance metrics</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">2. How We Use Your Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">We use your information solely for educational purposes:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>
                    <strong>Service Provision:</strong> To provide legislation checking, formatting, and submission
                    services
                  </li>
                  <li>
                    <strong>Educational Support:</strong> To deliver lessons, resources, and learning materials
                  </li>
                  <li>
                    <strong>Communication:</strong> To send important updates about your submissions and account
                  </li>
                  <li>
                    <strong>Improvement:</strong> To enhance our services and develop new educational features
                  </li>
                  <li>
                    <strong>Security:</strong> To protect against fraud, abuse, and security threats
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Lock className="h-6 w-6 text-red-600" />
                  <CardTitle className="text-xl text-gray-900">3. Data Security Measures</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">We implement comprehensive security measures to protect your data:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-900 mb-2">Encryption</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• 256-bit AES encryption for data at rest</li>
                      <li>• TLS 1.3 for data in transit</li>
                      <li>• Encrypted database storage</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-900 mb-2">Access Controls</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Multi-factor authentication</li>
                      <li>• Role-based access permissions</li>
                      <li>• Regular access audits</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-900 mb-2">Infrastructure</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Secure cloud hosting</li>
                      <li>• Regular security updates</li>
                      <li>• Automated backup systems</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-900 mb-2">Monitoring</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• 24/7 security monitoring</li>
                      <li>• Intrusion detection systems</li>
                      <li>• Regular security assessments</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">4. Information Sharing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  <strong>We do not sell, trade, or rent your personal information to third parties.</strong>
                </p>
                <p className="text-gray-700">We may share information only in these limited circumstances:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>
                    <strong>Educational Purpose:</strong> With your debate captains when you submit legislation (as
                    intended by the service)
                  </li>
                  <li>
                    <strong>Legal Requirements:</strong> When required by law or to protect our rights and safety
                  </li>
                  <li>
                    <strong>Service Providers:</strong> With trusted partners who help us operate the service (under
                    strict confidentiality agreements)
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">5. Your Rights and Choices</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">You have the following rights regarding your personal information:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Access and Control</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• View your personal information</li>
                      <li>• Update your account details</li>
                      <li>• Download your data</li>
                      <li>• Delete your account</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Privacy Controls</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Opt out of non-essential communications</li>
                      <li>• Control data sharing preferences</li>
                      <li>• Request data correction</li>
                      <li>• File privacy complaints</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">6. Data Retention</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">We retain your information only as long as necessary:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>
                    <strong>Account Information:</strong> Until you delete your account or request removal
                  </li>
                  <li>
                    <strong>Legislation Content:</strong> As long as needed for educational purposes or as requested
                  </li>
                  <li>
                    <strong>Usage Data:</strong> Aggregated and anonymized data may be retained for service improvement
                  </li>
                  <li>
                    <strong>Security Logs:</strong> Retained for security monitoring and compliance purposes
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">7. Student Privacy (FERPA Compliance)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  As an educational tool for high school students, we comply with applicable student privacy laws:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>We collect only information necessary for educational purposes</li>
                  <li>Student data is not used for commercial purposes</li>
                  <li>Parents and students have rights to access and control their information</li>
                  <li>We maintain appropriate safeguards for student records</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">8. Cookies and Tracking</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">We use cookies and similar technologies to:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Maintain your login session securely</li>
                  <li>Remember your preferences and settings</li>
                  <li>Analyze usage patterns to improve our service</li>
                  <li>Ensure security and prevent fraud</li>
                </ul>
                <p className="text-gray-700">
                  You can control cookie settings through your browser, though some features may not work properly if
                  cookies are disabled.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">9. Changes to This Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  We may update this Privacy Policy from time to time. We will notify you of any material changes by:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Posting the updated policy on our website</li>
                  <li>Sending an email notification to registered users</li>
                  <li>Providing at least 30 days notice for significant changes</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">10. Contact Us</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  If you have any questions about this Privacy Policy or our data practices, please contact us:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-700">
                    <strong>Privacy Questions:</strong>{" "}
                    <a href="mailto:anikethmal@diagonaldebate.com" className="text-red-600 hover:text-red-700">
                      anikethmal@diagonaldebate.com
                    </a>
                  </p>
                  <p className="text-gray-700">
                    <strong>Technical Support:</strong>{" "}
                    <a href="mailto:adityajup@diagonaldebate.com" className="text-red-600 hover:text-red-700">
                      adityajup@diagonaldebate.com
                    </a>
                  </p>
                  <p className="text-gray-700">
                    <strong>Platform:</strong> DiagonalDebate
                  </p>
                  <p className="text-gray-700">
                    <strong>Organization:</strong> Rock Ridge High School Debate Team
                  </p>
                </div>
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                  <p className="text-red-800 font-medium">
                    <Eye className="inline h-4 w-4 mr-2" />
                    Your privacy matters to us. We're committed to transparency and will respond to all privacy
                    inquiries within 48 hours.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
