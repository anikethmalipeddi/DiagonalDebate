"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Search, Filter, ThumbsUp, ThumbsDown, Tag } from "lucide-react"

const contentionIdeas = [
  {
    id: 1,
    title: "Universal Healthcare Implementation",
    description: "Comprehensive analysis of single-payer healthcare systems and their economic impacts.",
    category: "Domestic",
    tags: ["Healthcare", "Economics", "Policy"],
    argumentsFor: [
      "Reduces overall healthcare costs",
      "Provides universal coverage",
      "Eliminates medical bankruptcies",
    ],
    argumentsAgainst: [
      "High government expenditure",
      "Potential for longer wait times",
      "Reduced competition in healthcare",
    ],
  },
  {
    id: 2,
    title: "Carbon Tax Implementation",
    description: "Economic incentives to reduce carbon emissions through taxation mechanisms.",
    category: "Economic",
    tags: ["Environment", "Taxation", "Climate"],
    argumentsFor: [
      "Market-based solution to climate change",
      "Generates revenue for green initiatives",
      "Encourages innovation in clean technology",
    ],
    argumentsAgainst: [
      "Increases costs for consumers",
      "May harm economic competitiveness",
      "Regressive impact on low-income families",
    ],
  },
  {
    id: 3,
    title: "NATO Expansion Policy",
    description: "Strategic implications of expanding NATO membership to additional countries.",
    category: "International",
    tags: ["Defense", "Diplomacy", "Security"],
    argumentsFor: ["Strengthens collective security", "Promotes democratic values", "Deters aggressive actions"],
    argumentsAgainst: [
      "May escalate tensions",
      "Increases military commitments",
      "Potential for entanglement in conflicts",
    ],
  },
  {
    id: 4,
    title: "Minimum Wage Increase",
    description: "Economic and social effects of raising the federal minimum wage.",
    category: "Economic",
    tags: ["Labor", "Economics", "Social Policy"],
    argumentsFor: ["Reduces income inequality", "Improves worker living standards", "Stimulates consumer spending"],
    argumentsAgainst: [
      "May increase unemployment",
      "Burden on small businesses",
      "Potential for automation acceleration",
    ],
  },
  {
    id: 5,
    title: "Immigration Reform",
    description: "Comprehensive approach to modernizing immigration laws and policies.",
    category: "Domestic",
    tags: ["Immigration", "Policy", "Social Issues"],
    argumentsFor: ["Addresses undocumented population", "Fills labor market needs", "Humanitarian considerations"],
    argumentsAgainst: ["Potential security concerns", "Economic competition for jobs", "Strain on public services"],
  },
  {
    id: 6,
    title: "Trade War Resolution",
    description: "Strategies for resolving international trade disputes and tariff conflicts.",
    category: "International",
    tags: ["Trade", "Economics", "Diplomacy"],
    argumentsFor: ["Reduces consumer prices", "Promotes global cooperation", "Increases economic efficiency"],
    argumentsAgainst: [
      "May harm domestic industries",
      "Reduces negotiating leverage",
      "Potential job losses in protected sectors",
    ],
  },
]

export default function ContentionIdeasPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [expandedCard, setExpandedCard] = useState(null)

  const categories = ["All", "Domestic", "Economic", "International"]

  const filteredIdeas = contentionIdeas.filter((idea) => {
    const matchesSearch =
      idea.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      idea.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      idea.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = selectedCategory === "All" || idea.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getCategoryColor = (category) => {
    switch (category) {
      case "Domestic":
        return "bg-red-100 text-red-800"
      case "Economic":
        return "bg-gray-100 text-gray-800"
      case "International":
        return "bg-gray-900 text-white"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Contention Idea Bank</h1>
        <p className="text-lg text-gray-600">Explore debate topics with comprehensive arguments and counterarguments</p>
      </div>

      {/* Search and Filter Section */}
      <div className="mb-8 space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder="Search contention ideas, topics, or tags..."
            className="pl-10 py-3 border-gray-300"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">Filter by category:</span>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              className={
                selectedCategory === category
                  ? "bg-red-600 hover:bg-red-700 text-white"
                  : "border-gray-300 text-gray-700 hover:bg-gray-50"
              }
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredIdeas.map((idea) => (
          <Card key={idea.id} className="hover:shadow-lg transition-shadow border-gray-200">
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <Badge className={getCategoryColor(idea.category)}>{idea.category}</Badge>
                <div className="flex space-x-1">
                  {idea.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs border-gray-300 text-gray-700">
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <CardTitle className="text-lg text-gray-900">{idea.title}</CardTitle>
              <CardDescription className="text-gray-600">{idea.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <ThumbsUp className="w-4 h-4 text-gray-700" />
                    <span className="font-semibold text-sm text-gray-900">Arguments For:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {idea.argumentsFor.slice(0, expandedCard === idea.id ? undefined : 2).map((arg, index) => (
                      <li key={index}>{arg}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <ThumbsDown className="w-4 h-4 text-red-600" />
                    <span className="font-semibold text-sm text-gray-900">Arguments Against:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {idea.argumentsAgainst.slice(0, expandedCard === idea.id ? undefined : 2).map((arg, index) => (
                      <li key={index}>{arg}</li>
                    ))}
                  </ul>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full border-gray-300 text-gray-700 hover:bg-gray-50"
                  onClick={() => setExpandedCard(expandedCard === idea.id ? null : idea.id)}
                >
                  {expandedCard === idea.id ? "Show Less" : "Show More Arguments"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredIdeas.length === 0 && (
        <div className="text-center py-12">
          <Search className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No results found</h3>
          <p className="text-gray-600">Try adjusting your search terms or filters</p>
        </div>
      )}
    </div>
  )
}
