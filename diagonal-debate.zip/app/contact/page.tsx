import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, MessageSquare, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">Get in Touch</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Contact <span className="text-red-600">DiagonalDebate</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Have questions, feedback, or need assistance? We're here to help you succeed in congressional debate.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-1 gap-8">
            <Card className="border-gray-200 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-8 w-8 text-red-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">General Inquiries</CardTitle>
                <CardDescription className="text-gray-600">
                  For questions about the platform, feature requests, or general support
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <p className="text-lg font-semibold text-gray-900 mb-2">Send any inquiries to:</p>
                  <a
                    href="mailto:anikethmal@diagonaldebate.com"
                    className="text-red-600 hover:text-red-700 text-xl font-medium transition-colors"
                  >
                    anikethmal@diagonaldebate.com
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Additional Information */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What to Include in Your Message</h2>
            <p className="text-lg text-gray-600">Help us help you by including relevant details</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-gray-200">
              <CardHeader className="text-center">
                <MessageSquare className="h-8 w-8 text-red-600 mx-auto mb-2" />
                <CardTitle className="text-lg text-gray-900">Bug Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Describe what you were trying to do</li>
                  <li>• What happened vs. what you expected</li>
                  <li>• Steps to reproduce the issue</li>
                  <li>• Your browser and device information</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader className="text-center">
                <MessageSquare className="h-8 w-8 text-gray-700 mx-auto mb-2" />
                <CardTitle className="text-lg text-gray-900">Feature Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Describe the feature you'd like</li>
                  <li>• Explain how it would help you</li>
                  <li>• Any specific requirements</li>
                  <li>• Priority level for your team</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader className="text-center">
                <Clock className="h-8 w-8 text-red-600 mx-auto mb-2" />
                <CardTitle className="text-lg text-gray-900">Response Time</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• General inquiries: 24-48 hours</li>
                  <li>• Bug reports: 12-24 hours</li>
                  <li>• Urgent issues: Same day</li>
                  <li>• Feature requests: 3-5 days</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Information */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Built by Debaters, for Debaters</h2>
          <p className="text-lg text-gray-600 mb-8">
            DiagonalDebate is developed and maintained by current and former members of the Rock Ridge High School
            debate team. We understand the challenges you face because we've been there too.
          </p>
          <div className="bg-gray-50 p-8 rounded-lg">
            <p className="text-gray-700">
              Whether you're struggling with legislation formatting, need help with the platform, or have ideas for new
              features, don't hesitate to reach out. We're committed to making DiagonalDebate the best tool possible for
              congressional debate preparation.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
