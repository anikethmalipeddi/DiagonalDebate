"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, Clock, Users, ExternalLink } from "lucide-react"

const lessons = [
  {
    id: 1,
    title: "Effective Rhetoric in Congressional Debate",
    description: "Learn the fundamentals of persuasive speaking and argumentation techniques.",
    duration: "45 min",
    difficulty: "Beginner",
    topics: ["Rhetoric", "Persuasion", "Speaking"],
    content:
      "This comprehensive lesson covers the essential elements of effective rhetoric in congressional debate, including ethos, pathos, and logos...",
  },
  {
    id: 2,
    title: "Bill Writing Fundamentals",
    description: "Master the structure and format of congressional legislation.",
    duration: "60 min",
    difficulty: "Intermediate",
    topics: ["Writing", "Structure", "Format"],
    content: "Understanding the proper format and structure of bills is crucial for success in congressional debate...",
  },
  {
    id: 3,
    title: "Speech Structure and Organization",
    description: "Organize your speeches for maximum impact and clarity.",
    duration: "30 min",
    difficulty: "Beginner",
    topics: ["Speech", "Organization", "Structure"],
    content: "A well-structured speech can make the difference between winning and losing a debate round...",
  },
  {
    id: 4,
    title: "Research and Evidence Evaluation",
    description: "Learn to find, evaluate, and present compelling evidence.",
    duration: "50 min",
    difficulty: "Advanced",
    topics: ["Research", "Evidence", "Analysis"],
    content: "Strong evidence is the backbone of any successful argument in congressional debate...",
  },
  {
    id: 5,
    title: "Parliamentary Procedure",
    description: "Navigate the rules and procedures of congressional debate.",
    duration: "40 min",
    difficulty: "Intermediate",
    topics: ["Procedure", "Rules", "Protocol"],
    content:
      "Understanding parliamentary procedure is essential for effective participation in congressional debate...",
  },
  {
    id: 6,
    title: "Cross-Examination Techniques",
    description: "Master the art of questioning and defending your positions.",
    duration: "35 min",
    difficulty: "Advanced",
    topics: ["Cross-Ex", "Questioning", "Defense"],
    content: "Effective cross-examination can strengthen your position while weakening your opponents...",
  },
]

export default function LessonsPage() {
  const [selectedLesson, setSelectedLesson] = useState(null)

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-gray-100 text-gray-800"
      case "Intermediate":
        return "bg-red-100 text-red-800"
      case "Advanced":
        return "bg-gray-900 text-white"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Debate Lessons</h1>
        <p className="text-lg text-gray-600">Comprehensive lessons to improve your congressional debate skills</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {lessons.map((lesson) => (
          <Card key={lesson.id} className="hover:shadow-lg transition-shadow border-gray-200">
            <CardHeader>
              <div className="flex justify-between items-start mb-2">
                <div className="bg-red-100 p-2 rounded-lg">
                  <BookOpen className="w-6 h-6 text-red-600" />
                </div>
                <Badge className={getDifficultyColor(lesson.difficulty)}>{lesson.difficulty}</Badge>
              </div>
              <CardTitle className="text-lg text-gray-900">{lesson.title}</CardTitle>
              <CardDescription className="text-gray-600">{lesson.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{lesson.duration}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4" />
                  <span>{lesson.topics.length} topics</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mb-4">
                {lesson.topics.map((topic, index) => (
                  <Badge key={index} variant="outline" className="text-xs border-gray-300 text-gray-700">
                    {topic}
                  </Badge>
                ))}
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    className="w-full bg-red-600 hover:bg-red-700 text-white"
                    onClick={() => setSelectedLesson(lesson)}
                  >
                    Start Lesson
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-gray-900">{lesson.title}</DialogTitle>
                    <DialogDescription className="text-gray-600">
                      {lesson.duration} • {lesson.difficulty} Level
                    </DialogDescription>
                  </DialogHeader>
                  <div className="py-4">
                    <p className="text-gray-700 mb-4">{lesson.content}</p>
                    <div className="flex space-x-2">
                      <Button className="flex-1 bg-red-600 hover:bg-red-700 text-white">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Open Full Lesson
                      </Button>
                      <Button variant="outline" className="border-gray-300 text-gray-700">
                        Download PDF
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
