import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { HelpCircle, Book, MessageCircle } from "lucide-react"

export default function HelpPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">Help Center</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Get <span className="text-red-600">Help & Support</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Need assistance with DiagonalDebate? Our help center is here to support your congressional debate journey.
            </p>
          </div>
        </div>
      </section>

      {/* Help Contact */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-1 gap-8">
            <Card className="border-gray-200 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <HelpCircle className="h-8 w-8 text-red-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Technical Support</CardTitle>
                <CardDescription className="text-gray-600">
                  Get help with technical issues, platform questions, and troubleshooting
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <p className="text-lg font-semibold text-gray-900 mb-2">Send inquiries to:</p>
                  <a
                    href="mailto:adityajup@diagonaldebate.com"
                    className="text-red-600 hover:text-red-700 text-xl font-medium transition-colors"
                  >
                    adityajup@diagonaldebate.com
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Help Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How We Can Help</h2>
            <p className="text-lg text-gray-600">Common areas where our support team can assist you</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-gray-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="bg-red-100 p-2 rounded-lg w-fit">
                  <Book className="h-6 w-6 text-red-600" />
                </div>
                <CardTitle className="text-lg text-gray-900">Platform Tutorial</CardTitle>
                <CardDescription className="text-gray-600">
                  Learn how to use DiagonalDebate's features effectively
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Getting started guide</li>
                  <li>• Legislation checker walkthrough</li>
                  <li>• Understanding feedback reports</li>
                  <li>• Submission process</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="bg-gray-100 p-2 rounded-lg w-fit">
                  <HelpCircle className="h-6 w-6 text-gray-700" />
                </div>
                <CardTitle className="text-lg text-gray-900">Technical Issues</CardTitle>
                <CardDescription className="text-gray-600">
                  Resolve bugs, errors, and technical problems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Login and account issues</li>
                  <li>• Form submission problems</li>
                  <li>• PDF generation errors</li>
                  <li>• Browser compatibility</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="bg-red-100 p-2 rounded-lg w-fit">
                  <MessageCircle className="h-6 w-6 text-red-600" />
                </div>
                <CardTitle className="text-lg text-gray-900">Debate Support</CardTitle>
                <CardDescription className="text-gray-600">
                  Get help with congressional debate best practices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• NSDA formatting requirements</li>
                  <li>• Legislation writing tips</li>
                  <li>• Template explanations</li>
                  <li>• Best practice recommendations</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Support Guidelines */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Getting the Best Support</h2>
            <p className="text-lg text-gray-600">Help us help you more effectively</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">When Contacting Support</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-gray-600 space-y-3">
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Describe your issue clearly and specifically</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Include screenshots if relevant</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>Mention your browser and device type</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>List the steps you've already tried</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Response Times</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-gray-600 space-y-3">
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>
                      <strong>Urgent issues:</strong> Same day response
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>
                      <strong>Technical problems:</strong> 12-24 hours
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>
                      <strong>General questions:</strong> 24-48 hours
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-600 mr-2">•</span>
                    <span>
                      <strong>Feature requests:</strong> 3-5 business days
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Need Immediate Help?</h2>
          <p className="text-lg text-gray-600 mb-8">
            If you're experiencing a critical issue that's preventing you from submitting legislation before a deadline,
            mark your email as "URGENT" in the subject line.
          </p>
          <div className="bg-red-50 border border-red-200 p-6 rounded-lg">
            <p className="text-red-800 font-medium">
              For time-sensitive issues during tournament preparation, we prioritize urgent requests and aim to respond
              within 2-4 hours during business hours.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
