"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, AlertCircle, Lightbulb, FileText, Send } from "lucide-react"

export default function LegislationCheckerPage() {
  const [formData, setFormData] = useState({
    type: "",
    category: "",
    number: "",
    title: "",
    text: "",
  })
  const [isReviewed, setIsReviewed] = useState(false)
  const [feedback, setFeedback] = useState({
    templateErrors: [],
    grammar: [],
    readability: { score: 0, suggestions: [] },
    aiSuggestions: [],
  })

  const isFormComplete = Object.values(formData).every((value) => value.trim() !== "")

  const handleReview = () => {
    // Simulate review process
    setFeedback({
      templateErrors: ['Missing "BE IT ENACTED" clause', 'Section numbering should start with "Section 1"'],
      grammar: [
        'Line 15: Consider using "shall" instead of "will"',
        "Line 23: Missing comma after introductory phrase",
      ],
      readability: {
        score: 85,
        suggestions: ["Consider breaking down complex sentences in paragraph 2", "Define technical terms for clarity"],
      },
      aiSuggestions: [
        "Consider adding a findings section to strengthen your argument",
        "The enforcement mechanism could be more specific",
        "Add a sunset clause for periodic review",
      ],
    })
    setIsReviewed(true)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Legislation Checker & Submission</h1>
        <p className="text-lg text-gray-600">
          Write, review, and submit your congressional debate legislation with confidence
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form Section */}
        <Card className="border-gray-200">
          <CardHeader>
            <CardTitle className="text-gray-900">Legislation Details</CardTitle>
            <CardDescription>Fill out all fields to enable the legislation review</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="type" className="text-gray-700">
                  Legislation Type
                </Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bill">Bill</SelectItem>
                    <SelectItem value="resolution">Resolution</SelectItem>
                    <SelectItem value="amendment">Amendment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="category" className="text-gray-700">
                  Category
                </Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger className="border-gray-300">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="domestic">Domestic</SelectItem>
                    <SelectItem value="economic">Economic</SelectItem>
                    <SelectItem value="international">International</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="number" className="text-gray-700">
                Legislation Number
              </Label>
              <Input
                id="number"
                placeholder="e.g., H.R. D420"
                className="border-gray-300"
                value={formData.number}
                onChange={(e) => setFormData({ ...formData, number: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="title" className="text-gray-700">
                Legislation Title
              </Label>
              <Input
                id="title"
                placeholder="Enter the full title of your legislation"
                className="border-gray-300"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="text" className="text-gray-700">
                Legislation Text
              </Label>
              <Textarea
                id="text"
                placeholder="Paste or type your complete legislation text here..."
                className="min-h-[300px] border-gray-300"
                value={formData.text}
                onChange={(e) => setFormData({ ...formData, text: e.target.value })}
              />
            </div>

            <div className="flex flex-col space-y-3">
              <Button
                onClick={handleReview}
                disabled={!isFormComplete}
                className="w-full bg-red-600 hover:bg-red-700 text-white"
              >
                <FileText className="w-4 h-4 mr-2" />
                Review My Legislation
              </Button>

              {isReviewed && (
                <Button className="w-full bg-gray-900 hover:bg-black text-white">
                  <Send className="w-4 h-4 mr-2" />
                  Submit to Captains
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Feedback Section */}
        <Card className="border-gray-200">
          <CardHeader>
            <CardTitle className="text-gray-900">Review Feedback</CardTitle>
            <CardDescription>
              {isReviewed
                ? "Review the feedback below before submitting"
                : 'Complete the form and click "Review" to see feedback'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isReviewed ? (
              <Tabs defaultValue="template" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-gray-100">
                  <TabsTrigger
                    value="template"
                    className="data-[state=active]:bg-red-600 data-[state=active]:text-white"
                  >
                    Template
                  </TabsTrigger>
                  <TabsTrigger
                    value="grammar"
                    className="data-[state=active]:bg-red-600 data-[state=active]:text-white"
                  >
                    Grammar
                  </TabsTrigger>
                  <TabsTrigger
                    value="readability"
                    className="data-[state=active]:bg-red-600 data-[state=active]:text-white"
                  >
                    Readability
                  </TabsTrigger>
                  <TabsTrigger value="ai" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">
                    AI Tips
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="template" className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    <h3 className="font-semibold text-gray-900">Template Errors</h3>
                    <Badge className="bg-red-100 text-red-800">{feedback.templateErrors.length}</Badge>
                  </div>
                  {feedback.templateErrors.map((error, index) => (
                    <div key={index} className="p-3 bg-red-50 border border-red-200 rounded-md">
                      <p className="text-sm text-red-800">{error}</p>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="grammar" className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 text-gray-600" />
                    <h3 className="font-semibold text-gray-900">Grammar Suggestions</h3>
                    <Badge className="bg-gray-100 text-gray-800">{feedback.grammar.length}</Badge>
                  </div>
                  {feedback.grammar.map((suggestion, index) => (
                    <div key={index} className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                      <p className="text-sm text-gray-800">{suggestion}</p>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="readability" className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-gray-700" />
                    <h3 className="font-semibold text-gray-900">Readability Score</h3>
                    <Badge className="bg-gray-100 text-gray-800">{feedback.readability.score}/100</Badge>
                  </div>
                  {feedback.readability.suggestions.map((suggestion, index) => (
                    <div key={index} className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                      <p className="text-sm text-gray-800">{suggestion}</p>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="ai" className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Lightbulb className="w-5 h-5 text-red-600" />
                    <h3 className="font-semibold text-gray-900">AI Suggestions</h3>
                    <Badge className="bg-red-100 text-red-800">{feedback.aiSuggestions.length}</Badge>
                  </div>
                  {feedback.aiSuggestions.map((suggestion, index) => (
                    <div key={index} className="p-3 bg-red-50 border border-red-200 rounded-md">
                      <p className="text-sm text-red-800">{suggestion}</p>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Fill out the form and click "Review My Legislation" to see detailed feedback</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
