import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Lock } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">Legal</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Terms of <span className="text-red-600">Service</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Please read these terms carefully before using DiagonalDebate
            </p>
            <p className="text-sm text-gray-500">Last updated: December 20, 2024</p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {/* Security Emphasis */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Shield className="h-8 w-8 text-red-600" />
                  <CardTitle className="text-2xl text-red-800">Security is Our Top Priority</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-red-700">
                  At DiagonalDebate, we implement industry-leading security measures to protect your data, legislation,
                  and personal information. Your privacy and security are fundamental to our service.
                </p>
              </CardContent>
            </Card>

            {/* Terms Sections */}
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">1. Acceptance of Terms</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  By accessing and using DiagonalDebate ("the Service"), you accept and agree to be bound by the terms
                  and provision of this agreement. If you do not agree to abide by the above, please do not use this
                  service.
                </p>
                <p className="text-gray-700">
                  These Terms of Service apply to all users of the Service, including without limitation users who are
                  browsers, vendors, customers, merchants, and/or contributors of content.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">2. Description of Service</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  DiagonalDebate is a web-based platform designed to help high school congressional debate students
                  create, refine, and submit legislation. The Service includes:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Automated legislation formatting and NSDA template checking</li>
                  <li>AI-powered grammar and clarity suggestions</li>
                  <li>PDF generation and email submission to debate captains</li>
                  <li>Educational resources and lesson materials</li>
                  <li>Searchable contention idea database</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">3. User Accounts and Security</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Lock className="h-5 w-5 text-red-600 mt-1" />
                  <div>
                    <p className="text-gray-700 mb-2">
                      <strong>Account Security:</strong> You are responsible for maintaining the confidentiality of your
                      account credentials. We implement advanced encryption and security measures to protect your data.
                    </p>
                  </div>
                </div>
                <p className="text-gray-700">
                  You must provide accurate and complete information when creating your account. You are responsible for
                  all activities that occur under your account.
                </p>
                <p className="text-gray-700">
                  You must immediately notify us of any unauthorized use of your account or any other breach of
                  security.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">4. Acceptable Use Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">You agree not to use the Service to:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Upload, post, or transmit any content that is unlawful, harmful, or inappropriate</li>
                  <li>Violate any applicable local, state, national, or international law</li>
                  <li>Impersonate any person or entity or misrepresent your affiliation</li>
                  <li>Interfere with or disrupt the Service or servers connected to the Service</li>
                  <li>Attempt to gain unauthorized access to any portion of the Service</li>
                  <li>Use the Service for any commercial purpose without our express written consent</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">5. Intellectual Property Rights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  The Service and its original content, features, and functionality are and will remain the exclusive
                  property of DiagonalDebate and its licensors. The Service is protected by copyright, trademark, and
                  other laws.
                </p>
                <p className="text-gray-700">
                  You retain ownership of any legislation or content you create using the Service. By using the Service,
                  you grant us a limited license to process, store, and transmit your content solely for the purpose of
                  providing the Service.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">6. Data Protection and Privacy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Shield className="h-5 w-5 text-red-600 mt-1" />
                  <div>
                    <p className="text-gray-700">
                      <strong>Security Commitment:</strong> We employ industry-standard security measures including
                      encryption, secure data transmission, and regular security audits to protect your information.
                    </p>
                  </div>
                </div>
                <p className="text-gray-700">
                  Your privacy is important to us. Please review our Privacy Policy, which also governs your use of the
                  Service, to understand our practices.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">7. Educational Use</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  DiagonalDebate is designed specifically for educational purposes in the context of high school
                  congressional debate. The Service is intended to:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>Enhance learning and skill development in debate and legislation writing</li>
                  <li>Provide educational resources and materials</li>
                  <li>Facilitate proper formatting and submission of debate materials</li>
                  <li>Support academic integrity and best practices in debate</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">8. Limitation of Liability</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  In no event shall DiagonalDebate, its directors, employees, partners, agents, suppliers, or affiliates
                  be liable for any indirect, incidental, special, consequential, or punitive damages, including without
                  limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your use
                  of the Service.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">9. Termination</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  We may terminate or suspend your account and bar access to the Service immediately, without prior
                  notice or liability, under our sole discretion, for any reason whatsoever, including without
                  limitation if you breach the Terms.
                </p>
                <p className="text-gray-700">
                  If you wish to terminate your account, you may simply discontinue using the Service.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">10. Changes to Terms</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a
                  revision is material, we will provide at least 30 days notice prior to any new terms taking effect.
                </p>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">11. Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-700">
                  If you have any questions about these Terms of Service, please contact us at:
                </p>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-700">
                    <strong>Email:</strong>{" "}
                    <a href="mailto:anikethmal@diagonaldebate.com" className="text-red-600 hover:text-red-700">
                      anikethmal@diagonaldebate.com
                    </a>
                  </p>
                  <p className="text-gray-700">
                    <strong>Platform:</strong> DiagonalDebate
                  </p>
                  <p className="text-gray-700">
                    <strong>Organization:</strong> Rock Ridge High School Debate Team
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
