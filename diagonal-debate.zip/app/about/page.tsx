import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Users, Award, Zap, BookOpen, FileText } from "lucide-react"

export default function AboutPage() {
  const features = [
    {
      icon: CheckCircle,
      title: "Automated Formatting & NSDA Checks",
      description: "Ensure your legislation meets all NSDA template requirements with automated structure validation.",
      color: "text-red-600",
    },
    {
      icon: Zap,
      title: "AI-Powered Suggestions",
      description: "Get intelligent recommendations for clarity, grammar, and argument strength from advanced AI.",
      color: "text-gray-700",
    },
    {
      icon: FileText,
      title: "Instant PDF Generation",
      description: "Generate properly formatted PDFs and automatically email them to your debate captains.",
      color: "text-red-600",
    },
    {
      icon: BookOpen,
      title: "Educational Resources",
      description: "Access comprehensive lessons and a searchable database of contention ideas.",
      color: "text-gray-700",
    },
  ]

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">About DiagonalDebate</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Empowering Congressional Debate with <span className="text-red-600">Innovation</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              DiagonalDebate was created to revolutionize how high school congressional debate students prepare, write,
              and submit legislation.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-lg text-gray-600 mb-8">
              DiagonalDebate eliminates the friction of back-and-forth edits, lost formatting, and inconsistent
              standards by offering an automated legislation checker and submission workflow. Students input their
              legislation text, and our system evaluates it against NSDA template standards, checks grammar and
              readability, provides AI-powered improvement suggestions, and ensures correct formatting before generating
              a properly named PDF.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Team Collaboration</h3>
                <p className="text-gray-600">Standardize processes across your entire debate team</p>
              </div>
              <div>
                <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Quality Assurance</h3>
                <p className="text-gray-600">Ensure every submission meets professional standards</p>
              </div>
              <div>
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Efficiency</h3>
                <p className="text-gray-600">Save time with automated checks and formatting</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What We Offer</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Everything you need to create, refine, and submit winning legislation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div
                      className={`p-2 rounded-lg ${feature.color === "text-red-600" ? "bg-red-100" : "bg-gray-100"}`}
                    >
                      <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <CardTitle className="text-xl text-gray-900">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Built for Rock Ridge High School</h2>
            <Card className="border-gray-200">
              <CardContent className="p-8">
                <p className="text-lg text-gray-700 mb-6">
                  DiagonalDebate was created as an internal tool for the Rock Ridge High School debate team to
                  standardize the process of writing and submitting congressional debate legislation. Traditionally,
                  debaters relied on Google Forms, email threads, and manually formatted documents that often contained
                  errors or inconsistencies.
                </p>
                <p className="text-lg text-gray-700 mb-6">
                  Our platform replaces that chaotic workflow with a centralized website where students can input their
                  legislation, receive automated feedback based on template adherence and clarity, and submit finalized
                  PDFs directly to captains.
                </p>
                <p className="text-lg text-gray-700">
                  The platform also includes educational resources (lessons) and a contention idea bank to help students
                  develop stronger arguments and learn effective bill writing. It is designed for ease of use,
                  integrates modern UI/UX principles, and incorporates AI and automation to improve the quality and
                  efficiency of the legislative process.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
