import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"

export const metadata: Metadata = {
  title: "DiagonalDebate - Congressional Debate Legislation Assistant",
  description: "Empowering high school congressional debate students with AI-powered legislation tools",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="antialiased font-sans">
        <Navigation />
        <main className="min-h-screen bg-white">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
