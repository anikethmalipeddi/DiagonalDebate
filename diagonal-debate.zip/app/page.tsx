import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, FileText, Zap, BookOpen, Users, Award, ArrowRight, Quote } from "lucide-react"

export default function HomePage() {
  const features = [
    {
      icon: CheckCircle,
      title: "Automated Formatting & NSDA Checks",
      description: "Ensure your legislation meets all NSDA template requirements with automated structure validation.",
      color: "text-red-600",
    },
    {
      icon: Zap,
      title: "AI-Powered Suggestions",
      description: "Get intelligent recommendations for clarity, grammar, and argument strength from advanced AI.",
      color: "text-gray-700",
    },
    {
      icon: FileText,
      title: "Instant PDF Generation",
      description: "Generate properly formatted PDFs and automatically email them to your debate captains.",
      color: "text-red-600",
    },
    {
      icon: BookOpen,
      title: "Educational Resources",
      description: "Access comprehensive lessons and a searchable database of contention ideas.",
      color: "text-gray-700",
    },
  ]

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-red-100 text-red-800 mb-6">Built for Rock Ridge High School</Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Empowering Congressional Debate with <span className="text-red-600">AI and Automation</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Transform your debate preparation with intelligent legislation checking, automated formatting, and
              comprehensive educational resources designed specifically for high school congressional debate.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/legislation-checker">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/lessons">
                <Button variant="outline" size="lg" className="border-gray-300 text-gray-700 px-8 py-3">
                  Explore Lessons
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Streamline Your Debate Workflow</h2>
            <p className="text-lg text-gray-600 mb-8">
              DiagonalDebate eliminates the friction of back-and-forth edits, lost formatting, and inconsistent
              standards by offering an automated legislation checker and submission workflow. Students input their
              legislation text, and our system evaluates it against NSDA template standards, checks grammar and
              readability, provides AI-powered improvement suggestions, and ensures correct formatting before generating
              a properly named PDF.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Team Collaboration</h3>
                <p className="text-gray-600">Standardize processes across your entire debate team</p>
              </div>
              <div>
                <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-gray-700" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Quality Assurance</h3>
                <p className="text-gray-600">Ensure every submission meets professional standards</p>
              </div>
              <div>
                <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Efficiency</h3>
                <p className="text-gray-600">Save time with automated checks and formatting</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Powerful Features for Debate Excellence</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Everything you need to create, refine, and submit winning legislation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div
                      className={`p-2 rounded-lg ${feature.color === "text-red-600" ? "bg-red-100" : "bg-gray-100"}`}
                    >
                      <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <CardTitle className="text-xl text-gray-900">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="border-gray-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <Quote className="h-12 w-12 text-red-600 mx-auto mb-6" />
                  <blockquote className="text-xl text-gray-700 mb-6 italic">
                    "DiagonalDebate has revolutionized how our team prepares legislation. The automated formatting and
                    AI suggestions have improved the quality of our submissions dramatically, and the time savings allow
                    us to focus more on developing strong arguments."
                  </blockquote>
                  <div className="flex items-center justify-center space-x-4">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                      <span className="text-red-600 font-semibold">JS</span>
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-gray-900">Aditya Jupally</p>
                      <p className="text-gray-600">Debater, Rock Ridge High School</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-red-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Elevate Your Debate Game?</h2>
          <p className="text-xl text-red-100 mb-8 max-w-2xl mx-auto">
            Join your teammates in using the most advanced congressional debate preparation platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth?mode=register">
              <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 px-8 py-3">
                Create Account
              </Button>
            </Link>
            <Link href="/legislation-checker">
              <Button variant="outline" size="lg" className="border-white text-red hover:bg-red-700 px-8 py-3">
                Try Legislation Checker
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
